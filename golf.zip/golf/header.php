<header class='kopa-page-header-1'>
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-0 text-left header-top-left">
							<ul>
								<li>
									<a href="#">Member login</a>
								</li>
								<li>
									<a href="sc-contact-us-1.html">Contact us</a>
								</li>
							</ul>					

						</div>
						
					</div>
				</div>
			</div>
			<div class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-lg-2 col-md-6 col-sm-6 col-xs-10">
							<div class="hamburger-menu kopa-pull-left kopa-dropdown-btn">
								<span class="ti-menu"></span>
							</div>
							<nav class="mobile-main-nav">
								<ul class="mobile-main-menu">
									<li>
										<a href="#">Home</a>
										
									</li>
									<li>
										<a href="#">the course</a>
										<ul >
											<li>
												<a href="course-1.html">book a tee time</a>
											</li>
											<li>
												<a href="#">photo Gallery</a>
												<ul>
													<li>
														<a href="course-2.html">photo Gallery style 1</a>
													</li>
													<li>
														<a href="course-3.html">photo Gallery style 2</a>
													</li>
												</ul>
											</li>	
											<li>
												<a href="course-4.html">Rates</a>
											</li>		
											<li>
												<a href="#">hole by hole</a>
												<ul>
													<li>
														<a href="course-5.html">hole by hole fullwidth</a>
													</li>
													<li>
														<a href="course-6.html">hole by hole left sidebar</a>
													</li>
												</ul>
											</li>	
											<li>
												<a href="course-7.html">Instruction</a>
											</li>							
										</ul>
									</li>
									<li>
										<a href="#">the golf club</a>
										<ul >
											<li>
												<a href="club-1.html">the golf club</a>
											</li>
											<li>
												<a href="club-2.html">club history</a>
											</li>
											<li>
												<a href="club-3.html">club news</a>
											</li>
											<li>
												<a href="club-4.html">special programs</a>
											</li>
											<li>
												<a href="club-5.html">the club house</a>
											</li>																
										</ul>
									</li>
									<li>
										<a href="#">membership</a>
										<ul >
											<li>
												<a href="membership-1.html">Enquiry Form</a>
											</li>
											<li>
												<a href="membership-2.html">Membership fees</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="#">news & events</a>
										<ul >
											<li>
												<a href="#">news list</a>
												<ul>
													<li>
														<a href="news-1.html">news</a>
													</li>
												</ul>
											</li>
											<li>
												<a href="event-1.html">upcoming event</a>
												<ul>
													<li>
														<a href="event-1.html">upcoming event</a>
													</li>
													<li>
														<a href="event-5.html">upcoming event Calendar</a>
													</li>
												</ul>
											</li>
														
										</ul>
									</li>
								</ul>
							</nav>

							<div class="kopa-logo">
								<a href="index.html">
									<img src="images/header/logo.png" alt="">
								</a>
							</div>
						</div>
						<div class="col-lg-8 col-md-0 col-sm-0 col-xs-0">
							<nav class="main-nav ">
								<ul class="main-menu">
									<li class="current-menu-item">
										<a href="index-1.html">Home</a>
										
									</li>
									<li>
										<a href="#">the course</a>
										<ul >
											<li>
												<a href="course-1.html">book a tee time</a>
											</li>
											<li>
												<a href="course-2.html">photo Gallery</a>
												
											</li>	
											<li>
												<a href="course-4.html">Rates</a>
											</li>		
											<li>
												<a href="course-5.html">hole by hole</a>
												
											</li>	
											<li>
												<a href="course-7.html">Instruction</a>
											</li>							
										</ul>
									</li>
									<li>
										<a href="#">the golf club</a>
										<ul >
											<li>
												<a href="club-1.html">the golf club</a>
											</li>
											<li>
												<a href="club-2.html">club history</a>
											</li>
											<li>
												<a href="club-3.html">club news</a>
											</li>
											<li>
												<a href="club-4.html">special programs</a>
											</li>
											<li>
												<a href="club-5.html">the club house</a>
											</li>																
										</ul>
									</li>
									<li>
										<a href="#">membership</a>
										<ul >
											<li>
												<a href="membership-1.html">Enquiry Form</a>
											</li>
											<li>
												<a href="membership-2.html">Membership fees</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="#">news & events</a>
										<ul >
											<li>
												<a href="news-1.html">news list</a>
												
											</li>
											
											<li>
												<a href="event-1.html">upcoming event</a>
												<ul>
													<li>
														<a href="event-1.html">upcoming event</a>
													</li>
													<li>
														<a href="event-5.html">upcoming event Calendar</a>
													</li>
												</ul>
											</li>
															
									</ul>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-lg-2  col-md-6  col-sm-6  col-xs-2 text-right">
						<div class="search-box search-box-01">
							<div class="preSearch kopa-dropdown-btn"><span class="ti-search"></span></div>							
							<form method="GET" action="#">
								<input class="search-input" placeholder="Search..." type="text" value="" name="s" id="search">
								<button type="submit" class="search-submit">
									<span class="ti-search"></span>
								</button>										
							</form>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>